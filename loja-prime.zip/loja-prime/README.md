# Loja Prime

Mini loja de afiliado para divulgar produtos da Shopee.

## Como trocar os produtos
Abra o arquivo `script.js` e edite a lista `products`.

Exemplo:

```js
{
  name: 'Nome do produto',
  price: 'R$ 29,90',
  category: 'ofertas',
  image: 'LINK_DA_IMAGEM',
  link: 'SEU_LINK_DE_AFILIADO_DA_SHOPEE'
}
```

Categorias disponíveis:
- ofertas
- eletronicos
- casa
- moda
- acessorios

## Como hospedar no GitHub Pages
1. Crie uma conta ou entre no GitHub.
2. Crie um repositório chamado `loja-prime`.
3. Envie os arquivos `index.html`, `style.css`, `script.js` e `README.md`.
4. Vá em Settings > Pages.
5. Em Branch, escolha `main` e pasta `/root`.
6. Salve.
7. O GitHub vai gerar o link do site.
