const products = [
  {
    name: 'Fone Bluetooth Sem Fio',
    price: 'R$ 39,90',
    category: 'eletronicos',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',
    link: 'https://shopee.com.br/'
  },
  {
    name: 'Mini Liquidificador Portátil',
    price: 'R$ 49,90',
    category: 'casa',
    image: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&w=900&q=80',
    link: 'https://shopee.com.br/'
  },
  {
    name: 'Relógio Digital Esportivo',
    price: 'R$ 29,90',
    category: 'acessorios',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80',
    link: 'https://shopee.com.br/'
  },
  {
    name: 'Bolsa Feminina Casual',
    price: 'R$ 59,90',
    category: 'moda',
    image: 'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&w=900&q=80',
    link: 'https://shopee.com.br/'
  },
  {
    name: 'Luminária LED de Mesa',
    price: 'R$ 34,90',
    category: 'ofertas',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80',
    link: 'https://shopee.com.br/'
  },
  {
    name: 'Suporte de Celular Articulado',
    price: 'R$ 19,90',
    category: 'acessorios',
    image: 'https://images.unsplash.com/photo-1616410011236-7a42121dd981?auto=format&fit=crop&w=900&q=80',
    link: 'https://shopee.com.br/'
  }
];

const grid = document.getElementById('productGrid');
const searchInput = document.getElementById('searchInput');
const categoryButtons = document.querySelectorAll('.category');
let selectedCategory = 'todos';

function formatCategory(category) {
  const names = {
    eletronicos: 'Eletrônicos',
    casa: 'Casa',
    acessorios: 'Acessórios',
    moda: 'Moda',
    ofertas: 'Oferta'
  };
  return names[category] || category;
}

function renderProducts() {
  const search = searchInput.value.toLowerCase().trim();
  const filtered = products.filter(product => {
    const matchCategory = selectedCategory === 'todos' || product.category === selectedCategory;
    const matchSearch = product.name.toLowerCase().includes(search);
    return matchCategory && matchSearch;
  });

  grid.innerHTML = filtered.map(product => `
    <article class="product-card">
      <img src="${product.image}" alt="${product.name}">
      <div class="product-content">
        <small>${formatCategory(product.category)}</small>
        <h3>${product.name}</h3>
        <div class="price">${product.price}</div>
        <a href="${product.link}" target="_blank" rel="noopener noreferrer">Ver na Shopee</a>
      </div>
    </article>
  `).join('');

  if (!filtered.length) {
    grid.innerHTML = '<p class="empty">Nenhum produto encontrado.</p>';
  }
}

categoryButtons.forEach(button => {
  button.addEventListener('click', () => {
    categoryButtons.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    selectedCategory = button.dataset.category;
    renderProducts();
  });
});

searchInput.addEventListener('input', renderProducts);
renderProducts();
